package utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class SimpleScreenshoter implements Screenshoter {

    public byte[] takeScreenshot() {
        WebDriver driver = WebDriverSingleton.getWebdriverInstance();
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

}