package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import page_object.LoginPage;
import page_object.PageFactory;
import utils.WebDriverSingleton;

import java.util.concurrent.TimeUnit;

/**
 * Created by TTN on 03.08.2017.
 */
@CucumberOptions(strict = true, plugin = {"json:target/cucumber-report.json",
        "html:target/cucumber-report"}, tags = "@smokeTest", features = "src/test/resources/gmail_basic.feature", glue = {"steps"})
public class GmailCucumberTestNgTest extends AbstractTestNGCucumberTests {

    private static WebDriver driver = WebDriverSingleton.getWebdriverInstance();

    @BeforeClass(description = "Start browser, add implicit wait and maximize window")
    public void startBrowser() {
        // set a certain implicit wait timeout
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        // Maximize browser window
        driver.manage().window().maximize();

        LoginPage loginPage = (LoginPage) PageFactory.createPage("login");
        loginPage.open();
        loginPage.fillSearchInputLogin();
        loginPage.fillSearchInputPassword();
    }

    @AfterClass(description = "Stop Browser")
    public void stopBrowser() {
        driver.quit();
    }

}