package steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.testng.annotations.BeforeClass;
import page_object.LoginPage;
import page_object.PageFactory;
import page_object.SendMessagePage;

/**
 * Created by TTN on 03.08.2017.
 */
public class SendMessageSteps {

    private LoginPage loginPage;
    //private Screenshoter screenshoter;
    private SendMessagePage sendMessagePage;

    @Given("^open new message$")
    public void openNewMessage() throws Throwable {
        sendMessagePage = (SendMessagePage) PageFactory.createPage("send_message");
        sendMessagePage.clickNewMessageButton();
    }

    @And("^fill in message addressee (.*)$")
    public void fillInMessageAddressee(String addressee) throws Throwable {
        sendMessagePage.fillAddressee(addressee);
    }

    @And("^fill in message subject (.*)$")
    public void fillInMessageSubject(String subject) throws Throwable {
        sendMessagePage.fillSubject(subject);
    }

    @And("^fill in message body (.*)$")
    public void fillInMessageBody(String body) throws Throwable {
        sendMessagePage.fillMessage(body);
    }

    @And("^send message$")
    public void sendMessage() throws Throwable {
        sendMessagePage.clickGoButton();
        System.out.println();
    }

    @Then("^new email added to sent folder$")
    public void newEmailAddedToSentFolder() throws Throwable {
        //TODO: Add assertions
    }

}
