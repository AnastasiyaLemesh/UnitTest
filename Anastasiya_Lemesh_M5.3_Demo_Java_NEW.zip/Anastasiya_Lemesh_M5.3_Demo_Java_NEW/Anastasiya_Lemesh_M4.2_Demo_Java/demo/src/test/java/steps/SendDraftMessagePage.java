//package steps;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Then;
//import page_object.PageFactory;
//import page_object.RemoveDraftMessagePage;
//import page_object.SendMessagePage;
//import page_object.DraftMessagePage;
//
///**
// * Created by TTN on 04.08.2017.
// */
//public class SendDraftMessagePage {
//
//    DraftMessagePage draftMessagePage;
//    SendMessagePage sendMessagePage;
//    RemoveDraftMessagePage removeDraftMessagePage;
//
//    @And("^open draft message$")
//    public void openDraftMessage() throws Throwable {
//        removeDraftMessagePage = (RemoveDraftMessagePage) PageFactory.createPage("remove_draft");
//        removeDraftMessagePage.openDrafts();
//        removeDraftMessagePage.openLastDraft();
//    }
//
//    @And("^send draft message$")
//    public void sendDraftMessage() throws Throwable {
//        sendMessagePage.clickGoButton();
//    }
//
//    @Then("^check draft message is sent$")
//    public void checkDraftMessageIsSent() throws Throwable {
//       draftMessagePage.openSentEmails();
//       draftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");
//    }
//}
