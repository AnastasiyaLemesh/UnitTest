//package steps;
//
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Then;
//import page_object.NewMessagePage;
//import page_object.PageFactory;
//import page_object.RemoveDraftMessagePage;
//
//
//public class RemoveDraftMessageSteps {
//
//    private NewMessagePage newMessagePage;
//    private RemoveDraftMessagePage removeDraftMessagePage;
//
//    @And("^fill in new message$")
//    public void openAndFillInMessage() throws Throwable {
//        newMessagePage = (NewMessagePage) PageFactory.createPage("new_message");
//        newMessagePage.openNM();
//        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
//        newMessagePage.fillSearchInputSubject("Automated Testing");
//        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
//    }
//
//    @And("^close new message$")
//    public void closeNewMessage() throws Throwable {
//        newMessagePage.closeNMWindow();
//    }
//
//    @And("^open draft message$")
//    public void openDraftMessage() throws Throwable {
//        removeDraftMessagePage = (RemoveDraftMessagePage) PageFactory.createPage("remove_draft");
//        removeDraftMessagePage.openDrafts();
//        removeDraftMessagePage.openLastDraft();
//    }
//
//    @Then("^check draft message fields and remove message$")
//    public void checkDraftMessageFields() throws Throwable {
//        removeDraftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");
//
//        removeDraftMessagePage.removeMessage();
//    }
//}
