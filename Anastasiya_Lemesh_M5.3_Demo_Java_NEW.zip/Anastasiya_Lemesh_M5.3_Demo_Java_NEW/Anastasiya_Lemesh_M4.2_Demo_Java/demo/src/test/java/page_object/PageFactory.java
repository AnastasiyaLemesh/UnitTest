package page_object;

/**
 * Created by TTN on 26.07.2017.
 */
public final class PageFactory {

    public static AbstractPage createPage(String name) {
        if ("draft".equalsIgnoreCase(name)) {
            return new DraftMessagePage();
        }
        if ("login".equalsIgnoreCase(name)) {
            return new LoginPage();
        }
        if ("new_message".equalsIgnoreCase(name)) {
            return new NewMessagePage();
        }
        if ("remove_draft".equalsIgnoreCase(name)) {
            return new RemoveDraftMessagePage();
        }
        if ("send_message".equalsIgnoreCase(name)) {
            return new SendMessagePage();
        }
        throw new RuntimeException("Couldn't create page");
    }

}
