package user;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by TTN on 23.08.2017.
 */
public class User {
    private Integer id;
    private String name;

    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Integer getId(){
        return id;
    }

    public String getName() {
        return name;
    }
}
