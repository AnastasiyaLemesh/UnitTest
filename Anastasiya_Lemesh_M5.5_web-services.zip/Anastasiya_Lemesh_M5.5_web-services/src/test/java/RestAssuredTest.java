import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import user.User;

import static io.restassured.RestAssured.given;

/**
 * Created by TTN on 23.08.2017.
 */
public class RestAssuredTest {

    @BeforeTest
    public void initTest() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void checkHttpStatusCode(){
        Response response = given().get("/users").andReturn();
        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code: " + actualStatusCode);
        Assert.assertEquals(actualStatusCode, 200);
    }

    @Test
    public void checkHttpResponseHeader(){
        Response response = given().get("/users").andReturn();
        String valueOfContentTypeHeader = response.getHeader("content-type");
        System.out.println("Value Of Content Type Header: " + valueOfContentTypeHeader);
        Assert.assertTrue(valueOfContentTypeHeader.contains("application/json; charset=utf-8"));
    }

    @Test
    public void checkHttpResponseBody(){
        Response response = given().get("/users").andReturn();
        User[] users = response.as(User[].class);

        int actualNumberOfReturnedUsers = 0;

        for (int i = 0; i < users.length; i++){
            if(users[i].getId() != null ){
                actualNumberOfReturnedUsers++;
            }
        }
        System.out.println("Actual Number Of Returned Users: " + actualNumberOfReturnedUsers);

        Assert.assertEquals(actualNumberOfReturnedUsers, 10);
    }
}

