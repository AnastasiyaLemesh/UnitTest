package utils;

/**
 * Created by TTN on 26.07.2017.
 */
public class LogScreenshoter implements Screenshoter {

    private Screenshoter screenshoter;

    public LogScreenshoter(Screenshoter screenshoter) {
        this.screenshoter = screenshoter;
    }

    public byte[] takeScreenshot() {
        byte[] screenshot = screenshoter.takeScreenshot();
        System.out.println("[INFO]: Make screenshot");
        return screenshot;
    }

}
