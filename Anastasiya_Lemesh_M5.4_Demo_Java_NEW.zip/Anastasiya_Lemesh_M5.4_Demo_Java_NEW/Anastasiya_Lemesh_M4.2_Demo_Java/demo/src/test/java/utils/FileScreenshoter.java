package utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

public class FileScreenshoter implements Screenshoter {

    private static final String SCREENSHOTS_NAME_TPL = "screenshots/scr";

    private Screenshoter screenshoter;

    public FileScreenshoter(Screenshoter screenshoter) {
        this.screenshoter = screenshoter;
    }

    public byte[] takeScreenshot() {
        byte[] screenshot = screenshoter.takeScreenshot();
        try {
            String screenshotName = SCREENSHOTS_NAME_TPL + System.nanoTime();
            File screenshotFile = new File(screenshotName + ".png");
            FileUtils.writeByteArrayToFile(screenshotFile, screenshot);
        } catch (IOException e) {
            System.out.println("[ERROR]: Failed to write screenshot");
        }
        return screenshot;
    }

}