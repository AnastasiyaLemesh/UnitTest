package utils;

/**
 * Created by TTN on 26.07.2017.
 */
public interface Screenshoter {

    byte[] takeScreenshot();

}
