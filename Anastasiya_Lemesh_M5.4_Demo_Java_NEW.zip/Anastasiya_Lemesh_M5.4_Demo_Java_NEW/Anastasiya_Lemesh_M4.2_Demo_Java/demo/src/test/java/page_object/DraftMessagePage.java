package page_object;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

public class DraftMessagePage extends AbstractPage {

    private static final By DRAFT_BUTTON_LOCATOR = By.xpath("//div[@class=\"TK\"]/div[4]");
    private static final By DRAFT_EMAILS_LOCATOR = By.xpath("//div[@id=\":2\"]/div/div[2]/div[4]/div[1]/div/table/tbody/tr");
    private static final By SEND_MESSAGE_LOCATOR = By.xpath("//table[@class=\"iN\"]/tbody/tr[2]/td/div/div/div[4]/table/tbody/tr/td/div/div[2]");
    private static final By DRAFT_BUTTON3_LOCATOR = By.xpath("//div[@class=\"TK\"]/div[3]");

    public void openDrafts() {
        driver.findElement(DRAFT_BUTTON_LOCATOR).click();
    }

    public void openLastDraft() {
        List<WebElement> draftsBefore = driver.findElements(DRAFT_EMAILS_LOCATOR);

        Assert.assertFalse(draftsBefore.isEmpty());

        WebElement draft = draftsBefore.get(0);

        draft.click();
    }

    public void sendMessage() {
        driver.findElement(SEND_MESSAGE_LOCATOR).click();
    }

    public void openSentEmails() {
        driver.findElement(DRAFT_BUTTON3_LOCATOR).click();
    }

    public void checkDraftFields(String to, String subject, String body){
        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"to\"]")).getAttribute("value"), to, "login is not correspond entered before");
        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"subjectbox\"]")).getAttribute("value"), subject, "");
        Assert.assertEquals(driver.findElement(By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div")).getText(), body);
    }

}
