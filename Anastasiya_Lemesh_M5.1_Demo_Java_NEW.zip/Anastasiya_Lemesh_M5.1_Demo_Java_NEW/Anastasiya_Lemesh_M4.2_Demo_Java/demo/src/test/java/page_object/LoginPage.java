package page_object;

import business_object.User;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

public class LoginPage extends AbstractPage {

    private static final By SEARCH_INPUT_LOGIN_LOCATOR = By.id("identifierId");
    private static final By SEARCH_INPUT_PASSWORD_LOCATOR = By.name("password");

    public LoginPage open() {
        driver.get("http://www.gmail.com");
        return this;
    }

    public LoginPage fillSearchInputLogin(){
        waitForElementVisible(SEARCH_INPUT_LOGIN_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_LOGIN_LOCATOR);
        new Actions(driver).sendKeys(handle, User.getLogin(), Keys.RETURN).build().perform();
        return this;
    }

    public LoginPage fillSearchInputPassword(){
        waitForElementVisible(SEARCH_INPUT_PASSWORD_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_PASSWORD_LOCATOR);
        new Actions(driver).sendKeys(handle, User.getPassword(), Keys.RETURN).build().perform();
        return this;
    }

}
