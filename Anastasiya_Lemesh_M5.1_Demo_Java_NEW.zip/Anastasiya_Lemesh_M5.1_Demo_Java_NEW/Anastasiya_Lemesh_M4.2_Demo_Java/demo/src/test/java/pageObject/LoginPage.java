package pageObject;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import utils.*;
import businessObject.User;

public class LoginPage extends utils.WebDriver {

    private static final By SEARCH_INPUT_LOGIN_LOCATOR = By.id("identifierId");
    private static final By SEARCH_INPUT_PASSWORD_LOCATOR = By.name("password");

    public LoginPage(utils.WebDriver driver){
        super(driver);
    }

    public LoginPage open() {
        driver.get("http://www.gmail.com");
        return this;
    }

    public LoginPage fillSearchInputLogin(User user){
        waitForElementVisible(SEARCH_INPUT_LOGIN_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_LOGIN_LOCATOR);
        new Actions(driver).sendKeys(handle, user.getLogin(), Keys.RETURN).build().perform();
        return this;
    }

    public LoginPage fillSearchInputPassword(User user){
        waitForElementVisible(SEARCH_INPUT_PASSWORD_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_PASSWORD_LOCATOR);
        new Actions(driver).sendKeys(handle, user.getPassword(), Keys.RETURN).build().perform();
        return this;
    }

}
