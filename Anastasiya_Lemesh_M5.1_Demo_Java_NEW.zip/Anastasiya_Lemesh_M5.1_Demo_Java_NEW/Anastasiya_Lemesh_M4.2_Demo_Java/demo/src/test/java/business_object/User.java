package business_object;

public class User {

    private static final String PASSWORD = "315820Kotic";
    private static final String LOGIN = "avlemesh@gmail.com";

    public static String getPassword() {
        return PASSWORD;
    }

    public static String getLogin() {
        return LOGIN;
    }

}
