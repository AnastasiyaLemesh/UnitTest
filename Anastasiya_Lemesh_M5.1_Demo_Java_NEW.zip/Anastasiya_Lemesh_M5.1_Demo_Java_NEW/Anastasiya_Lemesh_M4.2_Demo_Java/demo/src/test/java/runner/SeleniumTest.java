package runner;

import businessObject.User;
import com.google.common.base.Predicate;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import pageObject.*;

/**
 * Created by TTN on 17.06.2017.
 */
public class SeleniumTest {
    utils.WebDriver driver;


    @Test(description = "Send  message test")
    public void sendMessageTest() {
        LoginPage loginPage = new LoginPage((utils.WebDriver) driver);
        loginPage.open();
        loginPage.fillSearchInputLogin(new User());
        loginPage.fillSearchInputPassword(new User());
        SendMessage sendMessage = new SendMessage((utils.WebDriver) driver);

        sendMessage.clickNewMessageButton();
        sendMessage.fillAddressee();
        sendMessage.fillSubject();
        sendMessage.fillMessage();
        sendMessage.clickGoButton();




/*        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });*/

        /*SendMessage sendMessage = new SendMessage(driver);
        sendMessage.openNM();
        sendMessage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        sendMessage.fillSearchInputSubject("Automated Testing");
        sendMessage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        sendMessage.sendNMWindow();*/

    }
}
