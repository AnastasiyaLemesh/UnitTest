package runner;

import com.google.common.base.Predicate;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import page_object.*;
import utils.Screenshoter;
import utils.WebDriverSingleton;


public class SeleniumTest {
    WebDriver driver = WebDriverSingleton.getWebdriverInstance();

    @Test(description = "Send draft message test")
    public void sendDraftMessageTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.open();

        loginPage.fillSearchInputLogin();

        loginPage.fillSearchInputPassword();

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = new NewMessagePage();
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        DraftMessagePage draftMessagePage = new DraftMessagePage();
        draftMessagePage.openDrafts();
        draftMessagePage.openLastDraft();

        draftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        draftMessagePage.sendMessage();
        draftMessagePage.openSentEmails();
    }

    @Test(description = "Remove draft message test")
    public void removeDraftMessageTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.open();

        loginPage.fillSearchInputLogin();

        loginPage.fillSearchInputPassword();

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = new NewMessagePage();
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        RemoveDraftMessagePage removeDraftMessagePage = new RemoveDraftMessagePage();
        removeDraftMessagePage.openDrafts();
        removeDraftMessagePage.openLastDraft();

        removeDraftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        removeDraftMessagePage.removeMessage();
    }


    //for verifying 5.1
    @Test(description = "Send  message test")
    public void sendMessageTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.open();
        Screenshoter.takeScreenshot();

        loginPage.fillSearchInputLogin();
        Screenshoter.takeScreenshot();
        loginPage.fillSearchInputPassword();
        SendMessage sendMessage = new SendMessage();

        sendMessage.clickNewMessageButton();
        sendMessage.fillAddressee();
        sendMessage.fillSubject();
        sendMessage.fillMessage();
        sendMessage.clickGoButton();

    }
}
