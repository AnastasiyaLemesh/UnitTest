package businessObject;

/**
 * Created by TTN on 13.07.2017.
 */
public class User {

    private static final String PASSWORD = "315820Kotic";
    private static final String LOGIN = "avlemesh@gmail.com";

    public String getPassword() {
        return PASSWORD;
    }

    public String getLogin() {
        return LOGIN;
    }

}
