package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

/**
 * Created by TTN on 03.09.2017.
 */
public class FileScreenshoter {
    WebDriver driver = WebDriverSingleton.getWebdriverInstance();

    private static final String SCREENSHOTS_NAME_TPL = "screenshots/scr";

    public byte[] takeScreenshot() {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        try {
            String screenshotName = SCREENSHOTS_NAME_TPL + System.nanoTime();
            File screenshotFile = new File(screenshotName + ".png");
            FileUtils.writeByteArrayToFile(screenshotFile, screenshot);
        } catch (IOException e) {
            System.out.println("[ERROR]: Failed to write screenshot");
        }
        return screenshot;
    }
}
