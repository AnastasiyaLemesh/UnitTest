package utils;

/**
 * Created by TTN on 03.09.2017.
 */
public interface Screenshoter {
    byte[] takeScreenshot();
}
