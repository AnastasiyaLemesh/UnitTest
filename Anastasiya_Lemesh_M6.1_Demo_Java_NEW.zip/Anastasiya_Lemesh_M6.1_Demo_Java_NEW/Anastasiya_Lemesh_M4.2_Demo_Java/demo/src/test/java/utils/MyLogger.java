package utils;


import org.apache.log4j.Level;
import org.apache.log4j.Logger;


public class MyLogger {

    Logger logger = Logger.getLogger("myLogger");

    public void error(String message) {
        logger.error(message);
        logger.setLevel(Level.ERROR);
    }

    public void error(String message, Throwable throwable) {
        logger.error(message, throwable);
    }

    public void info(String message) {
        logger.info(message);
        logger.setLevel(Level.ALL);
    }

    public void debug(String message) {
        logger.debug(message);
        logger.setLevel(Level.DEBUG);

    }

    public void warn(String message) {
        logger.warn(message);
        logger.setLevel(Level.WARN);

    }

    public void trace(String message) {
        logger.trace(message);
        logger.setLevel(Level.TRACE);

    }
}
