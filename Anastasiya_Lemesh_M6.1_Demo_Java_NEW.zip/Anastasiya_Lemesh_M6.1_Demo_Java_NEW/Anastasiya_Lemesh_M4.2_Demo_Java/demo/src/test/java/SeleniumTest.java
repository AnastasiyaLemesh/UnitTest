import io.qameta.allure.Issue;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pageObject.LoginPage;
import pageObject.SendMessage;
import utils.FileScreenshoter;
import utils.Highlighting;
import utils.MyLogger;
import utils.WebDriverSingleton;

/**
 * Created by TTN on 17.06.2017.
 */
public class SeleniumTest {
    WebDriver driver = WebDriverSingleton.getWebdriverInstance();

//    @BeforeClass(description = "Start browser")
//    private void initBrowser() {
//        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
//        driver = new ChromeDriver();
//        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        driver.manage().window().maximize();
//    }

   /* @Test(description = "Send draft message test")
    public void sendDraftMessageTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.open();
        loginPage.fillSearchInputLogin();
        loginPage.fillSearchInputPassword();

        NewMessagePage newMessagePage = new NewMessagePage();
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        DraftMessagePage draftMessagePage = new DraftMessagePage();
        draftMessagePage.openDrafts();
        draftMessagePage.openLastDraft();

        draftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        draftMessagePage.sendMessage();
        draftMessagePage.openSentEmails();
    }

    @Test(description = "Remove draft message test")
    public void removeDraftMessageTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.open();

        loginPage.fillSearchInputLogin();

        loginPage.fillSearchInputPassword();

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = new NewMessagePage();
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        RemoveDraftMessagePage removeDraftMessagePage = new RemoveDraftMessagePage();
        removeDraftMessagePage.openDrafts();
        removeDraftMessagePage.openLastDraft();

        removeDraftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        removeDraftMessagePage.removeMessage();
    }*/

    @Test(description = "Send  message test")
    @Issue("first")
    public void sendMessageTest() {
        MyLogger logger = new MyLogger();
        FileScreenshoter fileScreenshoter = new FileScreenshoter();
        Highlighting highlighting = new Highlighting();

        try {
            LoginPage loginPage = new LoginPage().open().fillSearchInputLogin().fillSearchInputPassword();
        } catch (Exception ex){
            fileScreenshoter.takeScreenshot();
            logger.error("Login is failed", ex);
        }

        SendMessage sendMessage = new SendMessage();

//        loginPage.open();
//        loginPage.fillSearchInputLogin();
//        loginPage.fillSearchInputPassword();

        sendMessage.clickNewMessageButton();
        logger.info("New message button is clicked!");
        sendMessage.fillAddressee();
        logger.info("Addressee is filled!");
        sendMessage.fillSubject();
        logger.info("Subject is filled!");
        highlighting.highlightElement(SendMessage.getMessage());
        sendMessage.fillMessage();
        logger.info("Message is filled!");
        sendMessage.clickGoButton();



/*        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });*/

        /*SendMessage sendMessage = new SendMessage(driver);
        sendMessage.openNM();
        sendMessage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        sendMessage.fillSearchInputSubject("Automated Testing");
        sendMessage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        sendMessage.sendNMWindow();*/

    }
}
