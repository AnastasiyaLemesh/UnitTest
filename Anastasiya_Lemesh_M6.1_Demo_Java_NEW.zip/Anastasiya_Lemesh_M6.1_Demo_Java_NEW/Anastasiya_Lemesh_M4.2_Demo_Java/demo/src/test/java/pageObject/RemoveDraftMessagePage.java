package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;


public class RemoveDraftMessagePage extends AbstractPage {

    private static final By DRAFT_BUTTON_LOCATOR = By.xpath("//div[@class=\"TK\"]/div[4]");
    private static final By DRAFT_EMAILS_LOCATOR = By.xpath("//div[@id=\":2\"]/div/div[2]/div[4]/div[1]/div/table/tbody/tr");

    //TODO: change the REMOVE_MESSAGE_LOCATOR xpath
    //private static final By REMOVE_MESSAGE_LOCATOR = By.xpath("//table[@class=\"iN\"]/tdbody/tr[2]/td/div/div/div[4]/table/tbody/tr/td[6]/div/div[2]/div/div/div/div");

    private static final By REMOVE_MESSAGE_LOCATOR = By.xpath(".//*[@data-tooltip='Удалить черновик']//div");


//    public RemoveDraftMessagePage(WebDriver driver) {
//        super(driver);
//    }

    public void openDrafts() {
        driver.findElement(DRAFT_BUTTON_LOCATOR).click();
    }

    public void openLastDraft() {
        List<WebElement> draftsBefore = driver.findElements(DRAFT_EMAILS_LOCATOR);

        Assert.assertFalse(draftsBefore.isEmpty());

        WebElement draft = draftsBefore.get(0);

        draft.click();
    }

    public void checkDraftFields(String to, String subject, String body){
        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"to\"]")).getAttribute("value"), to);
        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"subjectbox\"]")).getAttribute("value"), subject);
        Assert.assertEquals(driver.findElement(By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div")).getText(), body);
    }

    public void removeMessage() {
        driver.findElement(REMOVE_MESSAGE_LOCATOR).click();
    }

}
