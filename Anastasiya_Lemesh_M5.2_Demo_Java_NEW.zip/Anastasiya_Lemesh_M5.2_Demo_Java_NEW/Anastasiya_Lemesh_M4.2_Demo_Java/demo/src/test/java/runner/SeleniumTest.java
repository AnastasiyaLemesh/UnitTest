package runner;

import com.google.common.base.Predicate;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import page_object.*;
import utils.*;


public class SeleniumTest {
    WebDriver driver = WebDriverSingleton.getWebdriverInstance();

    @Test(description = "Send draft message test")
    public void sendDraftMessageTest() {
        LoginPage loginPage = (LoginPage) PageFactory.createPage("login");
        loginPage.open();

        loginPage.fillSearchInputLogin();

        loginPage.fillSearchInputPassword();

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = (NewMessagePage) PageFactory.createPage("new_message");
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        DraftMessagePage draftMessagePage = (DraftMessagePage) PageFactory.createPage("draft_message");
        draftMessagePage.openDrafts();
        draftMessagePage.openLastDraft();

        draftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        draftMessagePage.sendMessage();
        draftMessagePage.openSentEmails();
    }

    @Test(description = "Remove draft message test")
    public void removeDraftMessageTest() {
        LoginPage loginPage = (LoginPage) PageFactory.createPage("login");
        loginPage.open();

        loginPage.fillSearchInputLogin();

        loginPage.fillSearchInputPassword();

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = (NewMessagePage) PageFactory.createPage("new_message");
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        RemoveDraftMessagePage removeDraftMessagePage = (RemoveDraftMessagePage) PageFactory.createPage("remove_draft");
        removeDraftMessagePage.openDrafts();
        removeDraftMessagePage.openLastDraft();

        removeDraftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        removeDraftMessagePage.removeMessage();
    }


    //for verifying 5.1
    @Test(description = "Send  message test")
    public void sendMessageTest() {
        Screenshoter screenshoter = new LogScreenshoter(new FileScreenshoter(new SimpleScreenshoter())); /// Decorator pattern: take screenshot -> write file -> log info

        LoginPage loginPage = (LoginPage) PageFactory.createPage("login");
        loginPage.open();
        screenshoter.takeScreenshot();

        loginPage.fillSearchInputLogin();
        screenshoter.takeScreenshot();
        loginPage.fillSearchInputPassword();
        SendMessagePage sendMessagePage = (SendMessagePage) PageFactory.createPage("send_message");

        sendMessagePage.clickNewMessageButton();
        sendMessagePage.fillAddressee();
        sendMessagePage.fillSubject();
        sendMessagePage.fillMessage();
        sendMessagePage.clickGoButton();

    }
}
