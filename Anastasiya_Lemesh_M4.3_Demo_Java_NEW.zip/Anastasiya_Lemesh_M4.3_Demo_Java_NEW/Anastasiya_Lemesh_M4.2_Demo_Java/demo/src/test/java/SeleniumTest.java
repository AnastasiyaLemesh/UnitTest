import com.google.common.base.Predicate;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObject.*;
import utils.WebDriverSingleton;

import java.util.concurrent.TimeUnit;

/**
 * Created by TTN on 17.06.2017.
 */
public class SeleniumTest {
    WebDriver driver = WebDriverSingleton.getWebdriverInstance();

//    @BeforeClass(description = "Start browser")
//    private void initBrowser() {
//        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
//        driver = new ChromeDriver();
//        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        driver.manage().window().maximize();
//    }

    /*@Test(description = "Send draft message test")
    public void sendDraftMessageTest() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.open();

        loginPage.fillSearchInputLogin("avlemesh@gmail.com");

        loginPage.fillSearchInputPassword("315820Kotic");

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = new NewMessagePage(driver);
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        DraftMessagePage draftMessagePage = new DraftMessagePage(driver);
        draftMessagePage.openDrafts();
        draftMessagePage.openLastDraft();

        draftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        draftMessagePage.sendMessage();
        draftMessagePage.openSentEmails();
    }

    @Test(description = "Remove draft message test")
    public void removeDraftMessageTest() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.open();

        loginPage.fillSearchInputLogin("avlemesh@gmail.com");

        loginPage.fillSearchInputPassword("315820Kotic");

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        NewMessagePage newMessagePage = new NewMessagePage(driver);
        newMessagePage.openNM();
        newMessagePage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        newMessagePage.fillSearchInputSubject("Automated Testing");
        newMessagePage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        newMessagePage.closeNMWindow();

        RemoveDraftMessagePage removeDraftMessagePage = new RemoveDraftMessagePage(driver);
        removeDraftMessagePage.openDrafts();
        removeDraftMessagePage.openLastDraft();

        removeDraftMessagePage.checkDraftFields("Anastasiya Lemesh <anastasiya.lemesh@gmail.com>", "Automated Testing", "Automated Testing: Selenium Tests Task");

        removeDraftMessagePage.removeMessage();
    }*/

    @Test(description = "Send  message test")
    public void sendMessageTest() {
        LoginPage loginPage = new LoginPage().open().fillSearchInputLogin().fillSearchInputPassword();
        SendMessage sendMessage = new SendMessage();

//        loginPage.open();
//        loginPage.fillSearchInputLogin();
//        loginPage.fillSearchInputPassword();

        sendMessage.clickNewMessageButton();
        sendMessage.fillAddressee();
        sendMessage.fillSubject();
        sendMessage.fillMessage();
        sendMessage.clickGoButton();




/*        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });*/

        /*SendMessage sendMessage = new SendMessage(driver);
        sendMessage.openNM();
        sendMessage.fillSearchInputAddressee("anastasiya.lemesh@gmail.com");
        sendMessage.fillSearchInputSubject("Automated Testing");
        sendMessage.fillSearchInputText("Automated Testing: Selenium Tests Task");
        sendMessage.sendNMWindow();*/

    }
}
