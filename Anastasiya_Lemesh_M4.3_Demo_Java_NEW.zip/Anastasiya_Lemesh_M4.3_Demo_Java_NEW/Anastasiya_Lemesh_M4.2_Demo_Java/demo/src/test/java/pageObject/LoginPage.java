package pageObject;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

public class LoginPage extends AbstractPage {

    private static final By SEARCH_INPUT_LOGIN_LOCATOR = By.id("identifierId");
    private static final By SEARCH_INPUT_PASSWORD_LOCATOR = By.name("password");

//    public LoginPage(WebDriver driver){
//        super(driver);
//    }

    public LoginPage open() {
        driver.get("http://www.gmail.com");
        return this;
    }

    public LoginPage fillSearchInputLogin(){
        waitForElementVisible(SEARCH_INPUT_LOGIN_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_LOGIN_LOCATOR);

        JavascriptExecutor jsExec=(JavascriptExecutor)driver;
        jsExec.executeScript("document.getElementById(\"identifierId\").value = \"avlemesh@gmail.com\";");

        new Actions(driver).sendKeys(handle, Keys.RETURN).build().perform();
        return this;
    }

    public LoginPage fillSearchInputPassword(){
        waitForElementVisible(SEARCH_INPUT_PASSWORD_LOCATOR);
        WebElement handle = driver.findElement(SEARCH_INPUT_PASSWORD_LOCATOR);
        new Actions(driver).sendKeys(handle, "315820Kotic", Keys.RETURN).build().perform();
        return this;
    }









   /* public LoginPage fillSearchInputLogin(String login){
        driver.findElement(SEARCH_INPUT_LOGIN_LOCATOR).sendKeys(login, Keys.ENTER);
        return this;
    }

    public LoginPage fillSearchInputPassword(String password){
        driver.findElement(SEARCH_INPUT_PASSWORD_LOCATOR).sendKeys(password, Keys.ENTER);
        return this;
    }

    public LoginPage open() {
        driver.get("http://www.gmail.com");
        return this;
    }*/

}
