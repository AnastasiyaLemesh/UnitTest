package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;

/**
 * Created by TTN on 27.06.2017.
 */
public class SendMessage extends AbstractPage {

    private static final By CLICK_NEW_MESSAGE_BUTTON = By.xpath("//div[@class=\"z0\"]/div");
    private static final By FILL_ADDRESSEE = By.xpath("//textarea[@name=\"to\"]");
    private static final By FILL_SUBJECT = By.xpath("//input[@name=\"subjectbox\"]");
    private static final By FILL_MESSAGE = By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div");
    private static final By CLICK_GO_BUTTON = By.xpath("//table[@class=\"iN\"]/tbody/tr[2]/td/div/div/div[4]/table/tbody/tr/td/div/div[2]");

//    public SendMessage(WebDriver driver) {
//        super(driver);
//    }

    public SendMessage clickNewMessageButton() {
        waitForElementVisible(CLICK_NEW_MESSAGE_BUTTON);
        highlightElement(CLICK_NEW_MESSAGE_BUTTON);
       // WebElement handle = driver.findElement(CLICK_NEW_MESSAGE_BUTTON);

        new Actions(driver).click(driver.findElement(CLICK_NEW_MESSAGE_BUTTON)).build().perform();
        unHighlightElement(CLICK_NEW_MESSAGE_BUTTON);
        return this;
    }

    public SendMessage fillAddressee(){
        waitForElementVisible(FILL_ADDRESSEE);
        WebElement handle = driver.findElement(FILL_ADDRESSEE);
        new Actions(driver).sendKeys(handle, "anastasiya.lemesh@gmail.com", Keys.TAB).build().perform();
        return this;
    }

    public SendMessage fillSubject(){
        waitForElementVisible(FILL_SUBJECT);
        WebElement handle = driver.findElement(FILL_SUBJECT);
        new Actions(driver).sendKeys(handle, "Automated Testing", Keys.TAB).build().perform();
        return this;
    }

    public SendMessage fillMessage(){
        waitForElementVisible(FILL_MESSAGE);
        highlightElement(FILL_MESSAGE);
        WebElement handle = driver.findElement(FILL_MESSAGE);
        new Actions(driver).sendKeys(handle, "Automated Testing: Selenium Tests Task").build().perform();
        unHighlightElement(FILL_MESSAGE);
        return this;
    }

    public SendMessage clickGoButton() {
        waitForElementVisible(CLICK_GO_BUTTON);
        highlightElement(CLICK_GO_BUTTON);
        WebElement handle = driver.findElement(CLICK_GO_BUTTON);
        new Actions(driver).click(handle).build().perform();
        unHighlightElement(CLICK_GO_BUTTON);
        return this;
    }




/*    public SendMessage openNM() {
        driver.findElement(GO_NM_BUTTON_LOCATOR).click();
        return this;
    }

    public SendMessage fillSearchInputAddressee(String addressee){
        driver.findElement(SEARCH_INPUT_ADDRESSEE_LOCATOR).sendKeys(addressee);
        return this;
    }

    public SendMessage fillSearchInputSubject(String subject){
        driver.findElement(SEARCH_INPUT_SUBJECT_LOCATOR).sendKeys(subject);
        return this;
    }

    public SendMessage fillSearchInputText(String body){
        driver.findElement(SEARCH_INPUT_TEXT_LOCATOR).sendKeys(body);
        return this;
    }
    public SendMessage sendNMWindow() {
        driver.findElement(GO_BUTTON_LOCATOR).click();
        return this;
    }*/
}
