package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class LoginPage extends AbstractPage {

    private static final By SEARCH_INPUT_LOGIN_LOCATOR = By.id("identifierId");
    private static final By SEARCH_INPUT_PASSWORD_LOCATOR = By.name("password");

    public LoginPage(WebDriver driver){
        super(driver);
    }

    public LoginPage fillSearchInputLogin(String login){
        driver.findElement(SEARCH_INPUT_LOGIN_LOCATOR).sendKeys(login, Keys.ENTER);
        return this;
    }

    public LoginPage fillSearchInputPassword(String password){
        driver.findElement(SEARCH_INPUT_PASSWORD_LOCATOR).sendKeys(password, Keys.ENTER);
        return this;
    }

    public LoginPage open() {
        driver.get("http://www.gmail.com");
        return this;
    }
}
