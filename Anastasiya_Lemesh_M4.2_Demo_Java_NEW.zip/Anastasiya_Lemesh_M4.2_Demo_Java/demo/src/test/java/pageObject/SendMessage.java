package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by TTN on 27.06.2017.
 */
public class SendMessage extends AbstractPage {

    private static final By GO_NM_BUTTON_LOCATOR = By.xpath("//div[@class=\"z0\"]/div");
    private static final By SEARCH_INPUT_ADDRESSEE_LOCATOR = By.xpath("//textarea[@name=\"to\"]");
    private static final By SEARCH_INPUT_SUBJECT_LOCATOR = By.xpath("//input[@name=\"subjectbox\"]");
    private static final By SEARCH_INPUT_TEXT_LOCATOR = By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div");
    private static final By GO_BUTTON_LOCATOR = By.xpath("//table[@class=\"iN\"]/tbody/tr[2]/td/div/div/div[4]/table/tbody/tr/td/div/div[2]");

    public SendMessage(WebDriver driver) {
        super(driver);
    }

    public SendMessage openNM() {
        driver.findElement(GO_NM_BUTTON_LOCATOR).click();
        return this;
    }

    public SendMessage fillSearchInputAddressee(String addressee){
        driver.findElement(SEARCH_INPUT_ADDRESSEE_LOCATOR).sendKeys(addressee);
        return this;
    }

    public SendMessage fillSearchInputSubject(String subject){
        driver.findElement(SEARCH_INPUT_SUBJECT_LOCATOR).sendKeys(subject);
        return this;
    }

    public SendMessage fillSearchInputText(String body){
        driver.findElement(SEARCH_INPUT_TEXT_LOCATOR).sendKeys(body);
        return this;
    }
    public SendMessage sendNMWindow() {
        driver.findElement(GO_BUTTON_LOCATOR).click();
        return this;
    }
}
