package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NewMessagePage extends AbstractPage {

    private static final By GO_NM_BUTTON_LOCATOR = By.xpath("//div[@class=\"z0\"]/div");
    private static final By SEARCH_INPUT_ADDRESSEE_LOCATOR = By.xpath("//textarea[@name=\"to\"]");
    private static final By SEARCH_INPUT_SUBJECT_LOCATOR = By.xpath("//input[@name=\"subjectbox\"]");
    private static final By SEARCH_INPUT_TEXT_LOCATOR = By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div");
    private static final By GO_BUTTON_LOCATOR = By.xpath("//td[@class=\"Hm\"]/img[3]");

    public NewMessagePage(WebDriver driver) {
        super(driver);
    }

    public NewMessagePage openNM() {
        driver.findElement(GO_NM_BUTTON_LOCATOR).click();
        return this;
    }

    public NewMessagePage fillSearchInputAddressee(String addressee){
        driver.findElement(SEARCH_INPUT_ADDRESSEE_LOCATOR).sendKeys(addressee);
        return this;
    }

    public NewMessagePage fillSearchInputSubject(String subject){
        driver.findElement(SEARCH_INPUT_SUBJECT_LOCATOR).sendKeys(subject);
        return this;
    }

    public NewMessagePage fillSearchInputText(String body){
        driver.findElement(SEARCH_INPUT_TEXT_LOCATOR).sendKeys(body);
        return this;
    }

    public NewMessagePage closeNMWindow() {
        driver.findElement(GO_BUTTON_LOCATOR).click();
        return this;
    }
}
