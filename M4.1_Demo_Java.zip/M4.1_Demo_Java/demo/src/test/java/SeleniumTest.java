import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by TTN on 17.06.2017.
 */
public class SeleniumTest {

    @Test
    public void testName() throws Exception {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        driver.get("http://www.gmail.com");

        driver.findElement(By.id("identifierId")).sendKeys("avlemesh@gmail.com", Keys.ENTER);
        driver.findElement(By.name("password")).sendKeys("315820Kotic", Keys.ENTER);

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("avlemesh@gmail.com");
            }
        });

        driver.findElement(By.xpath("//div[@class=\"z0\"]/div")).click();

        String addressee = "anastasiya.lemesh@gmail.com";
        String subject = "Automated Testing";
        String body = "Automated Testing: Selenium Tests Task";

        driver.findElement(By.xpath("//textarea[@name=\"to\"]")).sendKeys(addressee);
        driver.findElement(By.xpath("//input[@name=\"subjectbox\"]")).sendKeys(subject);
        driver.findElement(By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div")).sendKeys(body);

        driver.findElement(By.xpath("//td[@class=\"Hm\"]/img[3]")).click();

        driver.findElement(By.xpath("//div[@class=\"TK\"]/div[4]")).click();

        List<WebElement> draftsBefore = driver.findElements(By.xpath("//div[@id=\":2\"]/div/div[2]/div[4]/div[1]/div/table/tbody/tr"));

        Assert.assertFalse(draftsBefore.isEmpty());

        WebElement draft = draftsBefore.get(0);

        draft.click();

        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"to\"]")).getAttribute("value"), addressee);
        Assert.assertEquals(driver.findElement(By.xpath("//input[@name=\"subjectbox\"]")).getAttribute("value"), subject);
        Assert.assertEquals(driver.findElement(By.xpath("//table[@class=\"iN\"]/tbody/tr/td/div/div/div[2]/div/div/table/tbody/tr/td[2]/div[2]/div")).getText(), body);

        driver.findElement(By.xpath("//table[@class=\"iN\"]/tbody/tr[2]/td/div/div/div[4]/table/tbody/tr/td/div/div[2]")).click();

        driver.findElement(By.xpath("//div[@class=\"TK\"]/div[3]")).click();
    }
}
