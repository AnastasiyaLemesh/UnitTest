import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class SeleniumDemo {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

//        driver.get("https://amazon.com");
//        driver.findElement(By.cssSelector("#twotabsearchtextbox")).sendKeys("Iphone SE");
//        driver.findElement(By.xpath("//input[@value='Go']")).click();
//        driver.findElement(By.cssSelector("#result_0 a.s-access-detail-page")).click();
//        String price = driver.findElement(By.cssSelector("#priceblock_ourprice")).getText();
//        driver.close();
//        System.out.println("iPhone SE price is " + price);

        driver.get("http://www.gmail.com");

        driver.findElement(By.id("identifierId")).sendKeys("anastasiya.lemesh@gmail.com", Keys.ENTER);
        driver.findElement(By.name("password")).sendKeys("7115638kot", Keys.ENTER);

        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(new Predicate<WebDriver>() {
            public boolean apply(WebDriver webDriver) {
                return webDriver.getTitle().contains("anastasiya.lemesh@gmail.com");
            }
        });

        //TODO: Check successful login

        driver.findElement(By.xpath("//div[@class=\"z0\"]/div")).click();

        driver.findElement(By.id(":nk")).sendKeys("iharkrupenin@gmail .com");
        driver.findElement(By.id(":n3")).sendKeys("Automated Testing");
        driver.findElement(By.id(":o4")).sendKeys("Automated Testing: Selenium Tests Task");

        driver.findElement(By.id(":k7")).click();

        driver.findElement(By.id(":av")).click();

        //driver.navigate().to("");
        //driver.navigate().back();
    }
}
